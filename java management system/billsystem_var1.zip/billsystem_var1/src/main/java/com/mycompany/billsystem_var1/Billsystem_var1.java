/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.billsystem_var1;

/**
 *
 * @author rosan
 */
public class Billsystem_var1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
